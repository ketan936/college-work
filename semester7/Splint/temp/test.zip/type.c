#include <stdio.h>
#include <stdlib.h>

signed int fun(){
	return -155;	
}

int main(){
unsigned int x = fun();
x++;
return 0;
}
