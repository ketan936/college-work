
#include <stdlib.h>

void fun ()
{
int *m = (int *)malloc (sizeof (int));

}