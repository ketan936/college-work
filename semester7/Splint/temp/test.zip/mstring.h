typedef /*@abstract @*/ char *mstring;
