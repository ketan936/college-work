#include <stdio.h>

int main(){
int *a=NULL;
printf("%d",*a);
return 0;
}
