#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mstring.h"


int main(){
int c=10;
switch(c)
{
case 10:
	c=11;
case 11:
	c=13;
}
}
