#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mstring.h"
void fun(mstring a){
	int i = strlen(a);
}

int main(){
char *a = "Hello";
fun(a);
return 0;
}
