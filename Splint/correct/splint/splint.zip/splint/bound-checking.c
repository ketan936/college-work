#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mstring.h"


int main(){
int buf[10];
buf[11] = 100;
return 0;
}
