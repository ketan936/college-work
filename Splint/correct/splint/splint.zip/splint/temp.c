#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mstring.h"

int *i;

void fun(){
	int z = 100;
	i = &z;
	return ;
}

int main(){

return 0;
}
